# MoneyTrack – Catatan Keuangan Pribadi
Tugas P10 Pemrograman Mobile – Prodi Sistem dan Teknologi Informasi, Universitas Muhammadiyah Kotabumi

Teknologi: Java, XML Layout, SQLite, SharedPreferences, minSdk 24 (Android 7.0), targetSdk 34.

## 1. Cara Menjalankan di Android Studio
1. Ekstrak file ZIP, lalu buka Android Studio: **File > Open** dan pilih folder `MoneyTrack` (yang berisi `settings.gradle`).
2. Tunggu **Gradle Sync** selesai (perlu internet saat pertama kali). Android Studio versi Giraffe/Hedgehog atau lebih baru (memakai JDK 17) disarankan.
   Jika diminta, izinkan Android Studio mengunduh Gradle 8.4 dan Android SDK 34.
3. Pilih emulator (API 24 ke atas) atau hubungkan HP dengan USB debugging.
4. Tekan tombol **Run** (segitiga hijau).

Jika terjadi error Gradle: **File > Invalidate Caches > Invalidate and Restart**, lalu **Build > Clean Project** dan **Rebuild Project**.

## 2. Struktur Project
```
app/src/main/java/com/example/moneytrack/
  MoneyTrackApp.java          menerapkan tema tersimpan saat aplikasi dimulai
  MainActivity.java           wadah Bottom Navigation + onResume() baca pengaturan
  AddTransactionActivity.java form tambah / edit transaksi + validasi
  fragment/  DashboardFragment, TransactionFragment, StatisticsFragment, SettingsFragment
  adapter/   TransactionAdapter, CategorySummaryAdapter
  database/  DatabaseHelper (SQLite)
  model/     Transaction, CategorySummary
  view/      SimpleBarChartView (grafik batang tanpa library)
  utils/     PrefsManager (SharedPreferences), CurrencyUtils, DateUtils
app/src/main/res/ layout, drawable, menu, values, values-night
```

## 3. Penjelasan PrefsManager.java (SharedPreferences)
File preferensi: `moneytrack_prefs` (tersimpan di penyimpanan internal aplikasi).

| Method | Fungsi |
|---|---|
| `PrefsManager(Context)` | Membuka file `moneytrack_prefs` dengan mode private |
| `setUserName(String)` / `getUserName()` | Simpan / baca nama pengguna (default "Pengguna") |
| `setThemeMode(int)` / `getThemeMode()` | Simpan / baca tema: `MODE_NIGHT_YES` (Dark) atau `MODE_NIGHT_NO` (Light) |
| `applyTheme()` | Menerapkan tema tersimpan lewat `AppCompatDelegate.setDefaultNightMode()` |
| `setCurrency(String)` / `getCurrency()` | Simpan / baca mata uang (default "IDR") |
| `setNotificationEnabled(boolean)` / `isNotificationEnabled()` | Simpan / baca pengaturan notifikasi (default aktif) |
| `saveSettings(...)` | Menyimpan keempat pengaturan sekaligus dalam satu editor |

Cara kerja `apply()`: `prefs.edit().putString(...).apply()` mengubah data di memori seketika, lalu menulis ke file XML di
latar belakang (asynchronous) sehingga UI tidak tersendat. Data di file itulah yang bertahan setelah aplikasi ditutup atau di-Force Stop.

Cara kerja `onResume()`: dipanggil setiap layar tampil. `MainActivity.onResume()` membaca tema dari PrefsManager dan menyamakannya
dengan tema aktif; `SettingsFragment.onResume()` membaca nama, tema, dan notifikasi lalu menampilkannya di form;
`DashboardFragment.onResume()` membaca nama untuk sapaan dan memuat ulang saldo dari SQLite.

Transaksi TIDAK disimpan di SharedPreferences, melainkan di SQLite (`moneytrack.db`, tabel `transactions`).

## 4. Skenario Pengujian SharedPreferences (untuk video tugas)
1. Buka aplikasi MoneyTrack.
2. Ketuk menu **Pengaturan** di Bottom Navigation.
3. Aktifkan switch **Dark Mode**.
4. Ubah **Nama Pengguna** (misalnya "Rinn").
5. Ketuk **Simpan Pengaturan**. Muncul Toast dan tampilan berubah gelap.
6. Tekan tombol Home / keluar dari aplikasi (swipe dari recent apps).
7. Buka **Pengaturan Android > Aplikasi > MoneyTrack > Paksa Berhenti (Force Stop)**.
8. Buka kembali MoneyTrack.
9. Tunjukkan bahwa tampilan tetap Dark Mode, sapaan di Dashboard memakai nama baru, dan di menu Pengaturan nama serta switch tetap sesuai.

Alur kode: `Simpan` > `PrefsManager.saveSettings()` (apply) > `applyTheme()`. Saat dibuka lagi setelah Force Stop:
`MoneyTrackApp.onCreate()` > `PrefsManager.applyTheme()` > `MainActivity` tampil > `onResume()` membaca ulang pengaturan.

## 5. Skenario Pengujian Fitur Lain
| Fitur | Langkah | Hasil yang diharapkan |
|---|---|---|
| Tambah pemasukan | Dashboard > tombol +, pilih Pemasukan, nominal 5000000, kategori Gaji, deskripsi "Gaji bulanan", simpan | Saldo dan total pemasukan Rp 5.000.000 |
| Tambah pengeluaran | Tambah Pengeluaran 25000, kategori Makanan | Saldo berkurang, total pengeluaran naik |
| Validasi | Kosongkan nominal / isi 0 / kosongkan deskripsi, ketuk Simpan | Muncul pesan error di kolom terkait, data tidak tersimpan |
| Edit | Menu Transaksi > ikon pensil, ubah nominal, simpan | Daftar dan saldo Dashboard ikut berubah |
| Hapus | Menu Transaksi > ikon tempat sampah | Dialog konfirmasi; setelah Hapus, saldo diperbarui |
| Filter | Chip Semua / Pemasukan / Pengeluaran | Daftar sesuai jenis |
| Cari | Ketik kata pada kolom pencarian | Daftar tersaring berdasarkan deskripsi / kategori |
| Statistik | Menu Statistik | Total, selisih saldo, grafik, rincian per kategori |
| Data kosong | Instal baru tanpa transaksi | Tidak crash, tampil pesan kosong |
| Persistensi SQLite | Tambah transaksi, Force Stop, buka lagi | Transaksi masih ada |

## 6. Catatan
- Tombol notifikasi hanya menyimpan preferensi (sesuai kebutuhan tugas); belum mengirim notifikasi sungguhan.
- Mata uang saat ini hanya Rupiah (IDR).
- Folder `gradle/wrapper` hanya berisi pengaturan versi Gradle; Android Studio mengunduh Gradle otomatis.
