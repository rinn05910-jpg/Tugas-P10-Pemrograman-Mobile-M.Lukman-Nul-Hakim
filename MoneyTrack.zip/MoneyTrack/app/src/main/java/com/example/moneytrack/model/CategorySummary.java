package com.example.moneytrack.model;

/**
 * Ringkasan total nominal untuk satu kategori (dipakai di halaman Statistik).
 */
public class CategorySummary {

    private final String category;
    private final long total;

    public CategorySummary(String category, long total) {
        this.category = category;
        this.total = total;
    }

    public String getCategory() {
        return category;
    }

    public long getTotal() {
        return total;
    }
}
