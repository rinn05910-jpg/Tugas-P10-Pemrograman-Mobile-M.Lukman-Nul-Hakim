package com.example.moneytrack.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Utilitas tanggal. Di database tanggal disimpan sebagai teks "yyyy-MM-dd"
 * (mudah diurutkan dan difilter), sedangkan di layar ditampilkan "dd MMM yyyy".
 */
public class DateUtils {

    private static final String DB_PATTERN = "yyyy-MM-dd";
    private static final String DISPLAY_PATTERN = "dd MMM yyyy";

    private DateUtils() {
    }

    public static String today() {
        return new SimpleDateFormat(DB_PATTERN, Locale.US).format(new Date());
    }

    public static String toDbFormat(int year, int monthZeroBased, int day) {
        return String.format(Locale.US, "%04d-%02d-%02d", year, monthZeroBased + 1, day);
    }

    public static String toDisplay(String dbDate) {
        if (dbDate == null || dbDate.isEmpty()) {
            return "";
        }
        try {
            Date date = new SimpleDateFormat(DB_PATTERN, Locale.US).parse(dbDate);
            if (date == null) {
                return dbDate;
            }
            return new SimpleDateFormat(DISPLAY_PATTERN, new Locale("id", "ID")).format(date);
        } catch (ParseException e) {
            return dbDate;
        }
    }

    /** Mengubah teks yyyy-MM-dd menjadi Calendar; jika gagal, mengembalikan hari ini. */
    public static Calendar toCalendar(String dbDate) {
        Calendar calendar = Calendar.getInstance();
        if (dbDate == null || dbDate.isEmpty()) {
            return calendar;
        }
        try {
            Date date = new SimpleDateFormat(DB_PATTERN, Locale.US).parse(dbDate);
            if (date != null) {
                calendar.setTime(date);
            }
        } catch (ParseException ignored) {
            // memakai hari ini
        }
        return calendar;
    }
}
