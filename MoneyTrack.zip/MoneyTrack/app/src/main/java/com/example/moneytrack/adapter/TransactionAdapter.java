package com.example.moneytrack.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.moneytrack.R;
import com.example.moneytrack.model.Transaction;
import com.example.moneytrack.utils.CurrencyUtils;
import com.example.moneytrack.utils.DateUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Menampilkan daftar transaksi. Tombol edit/hapus hanya tampil bila showActions = true
 * (di Dashboard daftar hanya untuk dilihat).
 */
public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.ViewHolder> {

    public interface OnActionListener {
        void onEdit(Transaction transaction);

        void onDelete(Transaction transaction);
    }

    private final Context context;
    private final boolean showActions;
    private final OnActionListener listener;
    private final List<Transaction> items = new ArrayList<>();

    public TransactionAdapter(Context context, boolean showActions, OnActionListener listener) {
        this.context = context;
        this.showActions = showActions;
        this.listener = listener;
    }

    public void setItems(List<Transaction> newItems) {
        items.clear();
        items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_transaction, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final Transaction t = items.get(position);
        boolean income = t.isIncome();

        holder.tvCategory.setText(t.getCategory());
        holder.tvDescription.setText(t.getDescription());
        holder.tvDate.setText(DateUtils.toDisplay(t.getDate()));
        holder.tvAmount.setText(CurrencyUtils.formatSigned(t.getAmount(), income));

        int color = ContextCompat.getColor(context, income ? R.color.income : R.color.expense);
        holder.tvAmount.setTextColor(color);
        holder.ivType.setImageResource(income ? R.drawable.ic_income : R.drawable.ic_expense);
        holder.ivType.setColorFilter(color);
        holder.ivType.setBackgroundResource(income ? R.drawable.bg_icon_income : R.drawable.bg_icon_expense);

        if (showActions) {
            holder.layoutActions.setVisibility(View.VISIBLE);
            holder.btnEdit.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onEdit(t);
                }
            });
            holder.btnDelete.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onDelete(t);
                }
            });
        } else {
            holder.layoutActions.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final ImageView ivType;
        final TextView tvCategory;
        final TextView tvDescription;
        final TextView tvDate;
        final TextView tvAmount;
        final View layoutActions;
        final ImageButton btnEdit;
        final ImageButton btnDelete;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivType = itemView.findViewById(R.id.ivType);
            tvCategory = itemView.findViewById(R.id.tvCategory);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvAmount = itemView.findViewById(R.id.tvAmount);
            layoutActions = itemView.findViewById(R.id.layoutActions);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
