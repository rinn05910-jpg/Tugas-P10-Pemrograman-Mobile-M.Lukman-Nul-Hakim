package com.example.moneytrack.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.moneytrack.R;
import com.example.moneytrack.model.CategorySummary;
import com.example.moneytrack.utils.CurrencyUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Menampilkan total pengeluaran per kategori beserta persentasenya.
 */
public class CategorySummaryAdapter extends RecyclerView.Adapter<CategorySummaryAdapter.ViewHolder> {

    private final Context context;
    private final List<CategorySummary> items = new ArrayList<>();
    private long totalExpense = 0;

    public CategorySummaryAdapter(Context context) {
        this.context = context;
    }

    public void setItems(List<CategorySummary> newItems, long totalExpense) {
        items.clear();
        items.addAll(newItems);
        this.totalExpense = totalExpense;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_category_summary, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CategorySummary s = items.get(position);
        int percent = totalExpense > 0 ? (int) Math.round(s.getTotal() * 100.0 / totalExpense) : 0;

        holder.tvCategoryName.setText(s.getCategory());
        holder.tvCategoryAmount.setText(CurrencyUtils.format(s.getTotal()));
        holder.progressCategory.setProgress(percent);
        holder.tvCategoryPercent.setText(String.format(Locale.US, "%d%% dari total pengeluaran", percent));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView tvCategoryName;
        final TextView tvCategoryAmount;
        final TextView tvCategoryPercent;
        final ProgressBar progressCategory;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCategoryName = itemView.findViewById(R.id.tvCategoryName);
            tvCategoryAmount = itemView.findViewById(R.id.tvCategoryAmount);
            tvCategoryPercent = itemView.findViewById(R.id.tvCategoryPercent);
            progressCategory = itemView.findViewById(R.id.progressCategory);
        }
    }
}
