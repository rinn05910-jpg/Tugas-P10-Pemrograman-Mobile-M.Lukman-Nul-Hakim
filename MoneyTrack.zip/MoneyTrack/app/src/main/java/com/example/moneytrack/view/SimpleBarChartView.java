package com.example.moneytrack.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;

import androidx.core.content.ContextCompat;

import com.example.moneytrack.R;
import com.example.moneytrack.utils.CurrencyUtils;

/**
 * Grafik batang sederhana (pemasukan vs pengeluaran) yang digambar manual
 * dengan Canvas, sehingga tidak butuh library tambahan.
 */
public class SimpleBarChartView extends View {

    private long income = 0;
    private long expense = 0;

    private final Paint barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint valuePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    public SimpleBarChartView(Context context) {
        super(context);
        init();
    }

    public SimpleBarChartView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public SimpleBarChartView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        valuePaint.setTextAlign(Paint.Align.CENTER);
        valuePaint.setTextSize(sp(10));
        valuePaint.setFakeBoldText(true);

        labelPaint.setTextAlign(Paint.Align.CENTER);
        labelPaint.setTextSize(sp(12));

        linePaint.setStrokeWidth(dp(1));
    }

    public void setData(long income, long expense) {
        this.income = income;
        this.expense = expense;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int textColor = ContextCompat.getColor(getContext(), R.color.text_secondary);
        valuePaint.setColor(ContextCompat.getColor(getContext(), R.color.text_primary));
        labelPaint.setColor(textColor);
        linePaint.setColor(ContextCompat.getColor(getContext(), R.color.card_stroke));

        float w = getWidth();
        float h = getHeight();
        float topPad = dp(28);
        float bottomPad = dp(28);
        float baseY = h - bottomPad;
        float maxBarHeight = baseY - topPad;

        long max = Math.max(Math.max(income, expense), 1);
        float barW = w / 5f;
        float gap = (w - 2 * barW) / 3f;

        canvas.drawLine(0, baseY, w, baseY, linePaint);

        drawBar(canvas, gap, barW, baseY, maxBarHeight, income, max,
                R.color.income, getContext().getString(R.string.income));
        drawBar(canvas, gap * 2 + barW, barW, baseY, maxBarHeight, expense, max,
                R.color.expense, getContext().getString(R.string.expense));
    }

    private void drawBar(Canvas canvas, float x, float barW, float baseY, float maxBarHeight,
                         long value, long max, int colorRes, String label) {
        float barH = (float) value / (float) max * maxBarHeight;
        if (value > 0 && barH < dp(4)) {
            barH = dp(4);
        }
        float top = baseY - barH;

        barPaint.setColor(ContextCompat.getColor(getContext(), colorRes));
        rect.set(x, top, x + barW, baseY);
        canvas.drawRoundRect(rect, dp(8), dp(8), barPaint);

        canvas.drawText(CurrencyUtils.format(value), x + barW / 2f, top - dp(6), valuePaint);
        canvas.drawText(label, x + barW / 2f, baseY + dp(20), labelPaint);
    }

    private float dp(float value) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value,
                getResources().getDisplayMetrics());
    }

    private float sp(float value) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, value,
                getResources().getDisplayMetrics());
    }
}
