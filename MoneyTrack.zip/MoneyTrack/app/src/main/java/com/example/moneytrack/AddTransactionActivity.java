package com.example.moneytrack;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.moneytrack.database.DatabaseHelper;
import com.example.moneytrack.model.Transaction;
import com.example.moneytrack.utils.DateUtils;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.Calendar;

/**
 * Form untuk menambah atau mengedit transaksi.
 * Jika dibuka dengan EXTRA_TRANSACTION_ID, Activity ini masuk mode edit.
 */
public class AddTransactionActivity extends AppCompatActivity {

    public static final String EXTRA_TRANSACTION_ID = "extra_transaction_id";

    private RadioGroup rgType;
    private RadioButton rbIncome;
    private RadioButton rbExpense;
    private TextInputLayout tilAmount;
    private TextInputLayout tilCategory;
    private TextInputLayout tilDate;
    private TextInputLayout tilDescription;
    private TextInputEditText etAmount;
    private TextInputEditText etDate;
    private TextInputEditText etDescription;
    private AutoCompleteTextView actvCategory;
    private MaterialButton btnSave;
    private MaterialToolbar toolbar;

    private DatabaseHelper db;
    private long editId = -1;
    private String selectedDate = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_transaction);

        db = DatabaseHelper.getInstance(this);
        bindViews();

        toolbar.setNavigationOnClickListener(v -> finish());

        // Atur pilihan kategori awal (Pengeluaran), lalu pasang listener perubahan jenis
        rbExpense.setChecked(true);
        updateCategoryAdapter();
        rgType.setOnCheckedChangeListener((group, checkedId) -> {
            updateCategoryAdapter();
            actvCategory.setText("", false);
        });

        etDate.setOnClickListener(v -> showDatePicker());
        tilDate.setEndIconOnClickListener(v -> showDatePicker());
        btnSave.setOnClickListener(v -> saveTransaction());

        editId = getIntent().getLongExtra(EXTRA_TRANSACTION_ID, -1);
        if (editId != -1) {
            loadTransactionForEdit();
        } else {
            toolbar.setTitle(R.string.add_transaction);
            selectedDate = DateUtils.today();
            etDate.setText(DateUtils.toDisplay(selectedDate));
        }
    }

    private void bindViews() {
        toolbar = findViewById(R.id.toolbar);
        rgType = findViewById(R.id.rgType);
        rbIncome = findViewById(R.id.rbIncome);
        rbExpense = findViewById(R.id.rbExpense);
        tilAmount = findViewById(R.id.tilAmount);
        tilCategory = findViewById(R.id.tilCategory);
        tilDate = findViewById(R.id.tilDate);
        tilDescription = findViewById(R.id.tilDescription);
        etAmount = findViewById(R.id.etAmount);
        etDate = findViewById(R.id.etDate);
        etDescription = findViewById(R.id.etDescription);
        actvCategory = findViewById(R.id.actvCategory);
        btnSave = findViewById(R.id.btnSave);
    }

    private void updateCategoryAdapter() {
        int arrayRes = rbIncome.isChecked() ? R.array.categories_income : R.array.categories_expense;
        String[] categories = getResources().getStringArray(arrayRes);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, categories);
        actvCategory.setAdapter(adapter);
    }

    private void loadTransactionForEdit() {
        Transaction t = db.getTransactionById(editId);
        if (t == null) {
            Toast.makeText(this, R.string.msg_not_found, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        toolbar.setTitle(R.string.edit_transaction);
        btnSave.setText(R.string.save_changes);

        // Pilih jenis lebih dulu (listener akan mengganti daftar kategori), baru isi kategori
        if (t.isIncome()) {
            rbIncome.setChecked(true);
        } else {
            rbExpense.setChecked(true);
        }
        actvCategory.setText(t.getCategory(), false);
        etAmount.setText(String.valueOf(t.getAmount()));
        etDescription.setText(t.getDescription());
        selectedDate = t.getDate();
        etDate.setText(DateUtils.toDisplay(selectedDate));
    }

    private void showDatePicker() {
        Calendar cal = DateUtils.toCalendar(selectedDate);
        new DatePickerDialog(this, (view, year, month, day) -> {
            selectedDate = DateUtils.toDbFormat(year, month, day);
            etDate.setText(DateUtils.toDisplay(selectedDate));
            tilDate.setError(null);
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void saveTransaction() {
        tilAmount.setError(null);
        tilCategory.setError(null);
        tilDescription.setError(null);
        tilDate.setError(null);

        boolean valid = true;

        // Validasi nominal
        String amountText = etAmount.getText() == null ? "" : etAmount.getText().toString().trim();
        long amount = 0;
        if (amountText.isEmpty()) {
            tilAmount.setError(getString(R.string.error_amount_empty));
            valid = false;
        } else {
            try {
                amount = Long.parseLong(amountText);
                if (amount <= 0) {
                    tilAmount.setError(getString(R.string.error_amount_invalid));
                    valid = false;
                }
            } catch (NumberFormatException e) {
                tilAmount.setError(getString(R.string.error_amount_invalid));
                valid = false;
            }
        }

        // Validasi kategori
        String category = actvCategory.getText().toString().trim();
        if (category.isEmpty()) {
            tilCategory.setError(getString(R.string.error_category));
            valid = false;
        }

        // Validasi deskripsi
        String description = etDescription.getText() == null ? "" : etDescription.getText().toString().trim();
        if (description.isEmpty()) {
            tilDescription.setError(getString(R.string.error_description));
            valid = false;
        }

        // Validasi tanggal
        if (selectedDate == null || selectedDate.isEmpty()) {
            tilDate.setError(getString(R.string.error_date));
            valid = false;
        }

        if (!valid) {
            return;
        }

        String type = rbIncome.isChecked() ? Transaction.TYPE_INCOME : Transaction.TYPE_EXPENSE;
        Transaction t = new Transaction(type, amount, category, description, selectedDate);

        if (editId == -1) {
            db.addTransaction(t);
            Toast.makeText(this, R.string.msg_saved, Toast.LENGTH_SHORT).show();
        } else {
            t.setId(editId);
            db.updateTransaction(t);
            Toast.makeText(this, R.string.msg_updated, Toast.LENGTH_SHORT).show();
        }
        setResult(RESULT_OK);
        finish();
    }
}
