package com.example.moneytrack;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.Fragment;

import com.example.moneytrack.fragment.DashboardFragment;
import com.example.moneytrack.fragment.SettingsFragment;
import com.example.moneytrack.fragment.StatisticsFragment;
import com.example.moneytrack.fragment.TransactionFragment;
import com.example.moneytrack.utils.PrefsManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;

/**
 * Wadah utama aplikasi: menampung Bottom Navigation dan empat halaman (Fragment).
 */
public class MainActivity extends AppCompatActivity {

    private PrefsManager prefs;
    private BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new PrefsManager(this);
        setContentView(R.layout.activity_main);

        bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setOnItemSelectedListener(item -> {
            Fragment fragment = null;
            int id = item.getItemId();
            if (id == R.id.nav_dashboard) {
                fragment = new DashboardFragment();
            } else if (id == R.id.nav_transaction) {
                fragment = new TransactionFragment();
            } else if (id == R.id.nav_statistics) {
                fragment = new StatisticsFragment();
            } else if (id == R.id.nav_settings) {
                fragment = new SettingsFragment();
            }
            if (fragment == null) {
                return false;
            }
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
            return true;
        });
        // Tidak melakukan apa-apa saat menu yang sama diketuk lagi
        bottomNav.setOnItemReselectedListener(item -> { });

        // Halaman awal hanya dipilih saat pertama kali dibuat (bukan saat recreate karena ganti tema)
        if (savedInstanceState == null) {
            bottomNav.setSelectedItemId(R.id.nav_dashboard);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Baca ulang pengaturan tema dari SharedPreferences setiap Activity tampil
        int savedMode = prefs.getThemeMode();
        if (AppCompatDelegate.getDefaultNightMode() != savedMode) {
            AppCompatDelegate.setDefaultNightMode(savedMode);
        }
    }
}
