package com.example.moneytrack;

import android.app.Application;

import com.example.moneytrack.utils.PrefsManager;

/**
 * Dijalankan sekali saat proses aplikasi dibuat (termasuk setelah Force Stop).
 * Di sini tema tersimpan dibaca dari SharedPreferences dan langsung diterapkan,
 * sehingga layar pertama sudah memakai Dark/Light Mode pilihan pengguna.
 */
public class MoneyTrackApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        new PrefsManager(this).applyTheme();
    }
}
