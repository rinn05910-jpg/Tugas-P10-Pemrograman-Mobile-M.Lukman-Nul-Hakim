package com.example.moneytrack.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.moneytrack.model.CategorySummary;
import com.example.moneytrack.model.Transaction;

import java.util.ArrayList;
import java.util.List;

/**
 * DatabaseHelper: seluruh urusan SQLite ada di sini (CRUD, total, filter, pencarian).
 * Semua query memakai parameter "?" agar aman dari SQL Injection.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "moneytrack.db";
    private static final int DB_VERSION = 1;

    public static final String TABLE_TRANSACTIONS = "transactions";
    public static final String COL_ID = "id";
    public static final String COL_TYPE = "type";
    public static final String COL_AMOUNT = "amount";
    public static final String COL_CATEGORY = "category";
    public static final String COL_DESCRIPTION = "description";
    public static final String COL_DATE = "date";

    private static final String ORDER_NEWEST = COL_DATE + " DESC, " + COL_ID + " DESC";

    private static DatabaseHelper instance;

    /** Singleton agar seluruh aplikasi memakai satu koneksi database. */
    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }

    private DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_TRANSACTIONS + " ("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_TYPE + " TEXT NOT NULL, "
                + COL_AMOUNT + " INTEGER NOT NULL, "
                + COL_CATEGORY + " TEXT NOT NULL, "
                + COL_DESCRIPTION + " TEXT, "
                + COL_DATE + " TEXT NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Untuk tugas ini cukup membuat ulang tabel saat versi database naik.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TRANSACTIONS);
        onCreate(db);
    }

    // ===================== CREATE =====================

    /** Menambah transaksi baru. Mengembalikan ID baris, atau -1 jika gagal. */
    public long addTransaction(Transaction t) {
        SQLiteDatabase db = getWritableDatabase();
        return db.insert(TABLE_TRANSACTIONS, null, toValues(t));
    }

    // ===================== READ =====================

    public List<Transaction> getAllTransactions() {
        return queryList(null, null, ORDER_NEWEST, null);
    }

    public List<Transaction> getRecentTransactions(int limit) {
        return queryList(null, null, ORDER_NEWEST, String.valueOf(limit));
    }

    public Transaction getTransactionById(long id) {
        List<Transaction> list = queryList(COL_ID + " = ?",
                new String[]{String.valueOf(id)}, null, "1");
        return list.isEmpty() ? null : list.get(0);
    }

    /**
     * Pencarian + filter jenis sekaligus.
     *
     * @param keyword kata kunci (dicari di deskripsi dan kategori); boleh kosong
     * @param type    "INCOME", "EXPENSE", atau null untuk semua jenis
     */
    public List<Transaction> searchTransactions(String keyword, String type) {
        List<String> args = new ArrayList<>();
        StringBuilder where = new StringBuilder();

        if (type != null && !type.isEmpty()) {
            where.append(COL_TYPE).append(" = ?");
            args.add(type);
        }
        if (keyword != null && !keyword.trim().isEmpty()) {
            if (where.length() > 0) {
                where.append(" AND ");
            }
            where.append("(").append(COL_DESCRIPTION).append(" LIKE ? OR ")
                    .append(COL_CATEGORY).append(" LIKE ?)");
            String like = "%" + keyword.trim() + "%";
            args.add(like);
            args.add(like);
        }

        String selection = where.length() == 0 ? null : where.toString();
        String[] selectionArgs = args.isEmpty() ? null : args.toArray(new String[0]);
        return queryList(selection, selectionArgs, ORDER_NEWEST, null);
    }

    public List<Transaction> getTransactionsByCategory(String category) {
        return queryList(COL_CATEGORY + " = ?", new String[]{category}, ORDER_NEWEST, null);
    }

    /** date berformat yyyy-MM-dd. */
    public List<Transaction> getTransactionsByDate(String date) {
        return queryList(COL_DATE + " = ?", new String[]{date}, ORDER_NEWEST, null);
    }

    public List<Transaction> getTransactionsByCategoryAndDate(String category, String date) {
        return queryList(COL_CATEGORY + " = ? AND " + COL_DATE + " = ?",
                new String[]{category, date}, ORDER_NEWEST, null);
    }

    // ===================== UPDATE =====================

    /** Mengubah transaksi berdasarkan ID. Mengembalikan jumlah baris yang berubah. */
    public int updateTransaction(Transaction t) {
        SQLiteDatabase db = getWritableDatabase();
        return db.update(TABLE_TRANSACTIONS, toValues(t), COL_ID + " = ?",
                new String[]{String.valueOf(t.getId())});
    }

    // ===================== DELETE =====================

    public int deleteTransaction(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(TABLE_TRANSACTIONS, COL_ID + " = ?", new String[]{String.valueOf(id)});
    }

    // ===================== TOTAL =====================

    public long getTotalIncome() {
        return getTotalByType(Transaction.TYPE_INCOME);
    }

    public long getTotalExpense() {
        return getTotalByType(Transaction.TYPE_EXPENSE);
    }

    /** Saldo = total pemasukan - total pengeluaran. */
    public long getBalance() {
        return getTotalIncome() - getTotalExpense();
    }

    private long getTotalByType(String type) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT COALESCE(SUM(" + COL_AMOUNT + "), 0) FROM "
                + TABLE_TRANSACTIONS + " WHERE " + COL_TYPE + " = ?", new String[]{type})) {
            if (c.moveToFirst()) {
                return c.getLong(0);
            }
        }
        return 0;
    }

    /** Total pengeluaran per kategori, dari yang terbesar. */
    public List<CategorySummary> getExpenseSummaryByCategory() {
        List<CategorySummary> result = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT " + COL_CATEGORY + ", SUM(" + COL_AMOUNT + ") AS total FROM "
                + TABLE_TRANSACTIONS + " WHERE " + COL_TYPE + " = ? GROUP BY " + COL_CATEGORY
                + " ORDER BY total DESC", new String[]{Transaction.TYPE_EXPENSE})) {
            while (c.moveToNext()) {
                result.add(new CategorySummary(c.getString(0), c.getLong(1)));
            }
        }
        return result;
    }

    // ===================== HELPER =====================

    private ContentValues toValues(Transaction t) {
        ContentValues values = new ContentValues();
        values.put(COL_TYPE, t.getType());
        values.put(COL_AMOUNT, t.getAmount());
        values.put(COL_CATEGORY, t.getCategory());
        values.put(COL_DESCRIPTION, t.getDescription());
        values.put(COL_DATE, t.getDate());
        return values;
    }

    private List<Transaction> queryList(String selection, String[] selectionArgs,
                                        String orderBy, String limit) {
        List<Transaction> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.query(TABLE_TRANSACTIONS, null, selection, selectionArgs,
                null, null, orderBy, limit)) {
            while (c.moveToNext()) {
                list.add(new Transaction(
                        c.getLong(c.getColumnIndexOrThrow(COL_ID)),
                        c.getString(c.getColumnIndexOrThrow(COL_TYPE)),
                        c.getLong(c.getColumnIndexOrThrow(COL_AMOUNT)),
                        c.getString(c.getColumnIndexOrThrow(COL_CATEGORY)),
                        c.getString(c.getColumnIndexOrThrow(COL_DESCRIPTION)),
                        c.getString(c.getColumnIndexOrThrow(COL_DATE))));
            }
        }
        return list;
    }
}
